document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault(); // Evita que se recargue la página

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const errorMessage = document.getElementById('error-message');

  // Simulación de base de datos (usuario y contraseña fijos)
  const validUsername = 'admin';
  const validPassword = '1234';

  if (username === validUsername && password === validPassword) {
    // Redirige a la siguiente página
    window.location.href = 'home.html';
  } else {
    errorMessage.textContent = 'Usuario o contraseña incorrectos.';
  }
});

document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.carousel');
    var instances = M.Carousel.init(elems, options);
});

  // Or with jQuery

$(document).ready(function(){
    $('.carousel').carousel();
});